# Dataset

Place an authorized copy of the TripleTen coursework dataset `Churn.csv` here, or set `CHURN_DATA_PATH` to its location. The dataset is not included in this repository. Check its usage and redistribution terms before sharing it.
